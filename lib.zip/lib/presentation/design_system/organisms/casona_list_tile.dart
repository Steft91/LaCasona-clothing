import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';

class CasonaListTile extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? leading;
  final Widget? trailing;
  final VoidCallback? onTap;

  const CasonaListTile({
    super.key,
    required this.title,
    this.subtitle,
    this.leading,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(17),
        child: Ink(
          decoration: BoxDecoration(
            gradient: AppTheme.woodGradient,
            borderRadius: BorderRadius.circular(17),
            border: Border.all(color: AppTheme.lineGold, width: 1.2),
            boxShadow: const [
              BoxShadow(
                color: AppTheme.heavyShadow,
                offset: Offset(0, 12),
                blurRadius: 22,
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(5, 5, 5, 9),
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: AppTheme.parchmentGradient,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.burnishedGold),
              ),
              child: ListTile(
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                leading: leading == null
                    ? null
                    : DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: AppTheme.goldGradient,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppTheme.burnishedGold),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: IconTheme(
                            data: const IconThemeData(
                              color: AppTheme.deepWood,
                              size: 21,
                            ),
                            child: leading!,
                          ),
                        ),
                      ),
                title: Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: AppTheme.inkBrown,
                        fontWeight: FontWeight.w900,
                      ),
                ),
                subtitle: subtitle != null
                    ? Text(
                        subtitle!,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: AppTheme.carvedWood,
                              fontWeight: FontWeight.w700,
                            ),
                      )
                    : null,
                isThreeLine: subtitle != null && subtitle!.contains('\n'),
                trailing: trailing,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
